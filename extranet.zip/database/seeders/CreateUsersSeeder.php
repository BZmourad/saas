<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class CreateUsersSeeder extends Seeder
{
    public function run(): void
    {
        $user = User::create([
            'name' => 'Manager',
            'email' => 'extranet@frdomain.ca',
            'password' => bcrypt('12345678'),
            'email_verified_at' => now(),
        ]);
        $roleSuperAdmin = Role::create(['name' => 'Super Admin']);
        $permissions = Permission::where('type', 0)->pluck('id','id')->all();
        $roleSuperAdmin->syncPermissions($permissions);
        $user->assignRole([$roleSuperAdmin->id]);

        $users = [
            [
               'name'=>'Admin User',
               'email'=>'admin@gmail.com',
               'type'=>0,
               'password'=> bcrypt('123456'),
               'email_verified_at'=> now()
            ],
            [
                'name'=>'Client User',
                'email'=>'client@gmail.com',
                'type'=> 2,
                'password'=> bcrypt('123456'),
                'email_verified_at'=> now()
            ],
            [
                'name'=>'Candidat User',
                'email'=>'candidat@gmail.com',
                'type'=> 3,
                'password'=> bcrypt('123456'),
                'email_verified_at'=> now()
            ]
        ];

        foreach ($users as $key => $user) {
            User::create($user);
        }
    }
}
