<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Country;
use Illuminate\Support\Str;

class CountrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $countries = [
            ['Brésil', 'BRE'],
            ['Burkina Faso', 'BFA'],
            ['Cambodge', 'KHM'],
            ['Cameroun', 'CMR'],
            ['Colombie', 'COL'],
            ['Corée du Sud (South Korea)', 'KOR'],
            ['États-Unis', 'USA'],
            ['France', 'FRA'],
            ['Générique', 'GEN'],
            ['Grande-Bretagne', 'GRB'],
            ['Maroc', 'MAR'],
            ['Mexique', 'MEX'],
            ['Pologne', 'POL'],
            ['Sénégal', 'SEN'],
            ['Tunisie', 'TUN'],
            ['Canada', 'CAN'],
            ['Ile Maurice (MU)', 'MU'],
            ['Iran', 'Ira'],
            ['Nicaragua', 'Ni'],
            ['Argentine', 'ARG'],
            ['Ile Maurice (MAU)', 'MAU'],
            ['Belgique', 'BL'],
            ['Guatemala', 'GU'],
            ['Panama', 'PAN'],
            ['Algérie', 'ALG']
        ];
        foreach ($countries as $country) {
            Country::create([
                'name' => $country[0],
                'abbreviation' => $country[1]
            ]);
        }
    }
}
