<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Offer;

class OfferSeeder extends Seeder
{
    public function run(): void
    {
        for ($i=1; $i < 9; $i++) {
            Offer::create([
                'company' => 'company '.$i,
                'logo' => $i.'.jpg',
                'title' => 'poste title '.$i,
                'description' => 'company description'.$i,
                'price' => rand(1000,3000),
                'experience' => 'exp1, exp2, exp3',
            ]);
        }
    }
}
