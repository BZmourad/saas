<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissionsAdmin = [
            'access_dashboard',

            'access_users',
            'add_users',
            'edit_users',
            'delete_users',

            'access_roles',
            'add_roles',
            'edit_roles',
            'delete_roles',

            'access_countries',
            'add_countries',
            'edit_countries',
            'delete_countries',

            'access_members',
            'add_members',
            'edit_members',
            'delete_members',

            'access_customers',
            'add_customers',
            'edit_customers',
            'delete_customers',

            'access_offers',
            'add_offers',
            'edit_offers',
            'delete_offers',
        ];

        foreach ($permissionsAdmin as $permission) {
            Permission::create(['name' => $permission]);
        }

        $permissionsMember = [
            'access_dashboard_member',

            'access_users_member',
            'add_users_member',
            'edit_users_member',
            'delete_users_member',

            'access_roles_member',
            'add_roles_member',
            'edit_roles_member',
            'delete_roles_member',
        ];

        foreach ($permissionsMember as $permission) {
            Permission::create(['name' => $permission,'type'=> 1]);
        }
    }
}
