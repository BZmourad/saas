<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [HomeController::class, 'welcome'])->name('welcome');

Auth::routes(['verify' => true,'reset' => true,'register' => true]);

Route::get('/home', [HomeController::class, 'index'])->name('home');

Route::view('403', 'errors.permission');

Route::get('/setLang/{id}', [HomeController::class, 'setLang'])->name('setLang');

Route::get('/inactive', function () { return view('auth.inactive');})->name('inactive');

Route::get('/inaccepted', function () { return view('auth.inaccepted');})->name('inaccepted');

Route::get('/offers/{id}', [HomeController::class, 'getOffers'])->name('getOffers');

Route::get('/postulate/{id}', [HomeController::class, 'postulate'])->name('postulate');

Route::post('/postulate', [HomeController::class, 'candidature'])->name('candidature');

Route::view('test', 'test');
