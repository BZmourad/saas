<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\HomeAdminController;
use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\CountryController;
use App\Http\Controllers\Admin\MemberController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\OfferController;

Route::prefix('admin')->as('admin.')->middleware(['auth', 'user-access:admin', 'verified', 'Language', 'IsActive'])->group(function () {
    Route::get('/home', [HomeAdminController::class, 'index'])->name('home');
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile');
    Route::post('/profile/update1', [ProfileController::class, 'update1'])->name('profile.update1');
    Route::post('/profile/update2', [ProfileController::class, 'update2'])->name('profile.update2');
    Route::post('/profile/update3', [ProfileController::class, 'update3'])->name('profile.update3');
    Route::get('/profile/update4', [ProfileController::class, 'update4'])->name('profile.update4');
    Route::resource('roles',  RoleController::class);
    Route::post('/roles/update1', [RoleController::class,'update1'])->name('roles.update1');
    Route::resource('users',  UserController::class);
    Route::post('/users/update1', [UserController::class,'update1'])->name('users.update1');
    Route::resource('countries',  CountryController::class);
    Route::post('/countries/update1', [CountryController::class,'update1'])->name('countries.update1');
    Route::resource('members', MemberController::class);
    Route::post('/members/update1', [MemberController::class,'update1'])->name('members.update1');
    Route::get('/members/{id}/accept', [MemberController::class,'accept'])->name('members.accept');
    Route::resource('customers', CustomerController::class);
    Route::post('/customers/update1', [CustomerController::class,'update1'])->name('customers.update1');
    Route::resource('offers', OfferController::class);
    Route::post('/offers/update1', [OfferController::class,'update1'])->name('offers.update1');
});
