<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Candidat\HomeCandidatController;
use App\Http\Controllers\Candidat\ProfileCandidatController;
use App\Http\Controllers\Candidat\CandidatureCandidatController;

Route::prefix('candidat')->as('candidat.')->middleware(['auth', 'user-access:candidat', 'verified', 'Language', 'IsActive'])->group(function () {
    Route::get('/home', [HomeCandidatController::class, 'index'])->name('home');
    Route::get('/profile', [ProfileCandidatController::class, 'index'])->name('profile');
    Route::post('/profile/update1', [ProfileCandidatController::class, 'update1'])->name('profile.update1');
    Route::post('/profile/update2', [ProfileCandidatController::class, 'update2'])->name('profile.update2');
    Route::post('/profile/update3', [ProfileCandidatController::class, 'update3'])->name('profile.update3');
    Route::get('/profile/update4', [ProfileCandidatController::class, 'update4'])->name('profile.update4');
    Route::resource('candidatures',  CandidatureCandidatController::class);
});
