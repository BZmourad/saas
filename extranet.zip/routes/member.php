<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Member\HomeMemberController;
use App\Http\Controllers\Member\ProfileMemberController;
use App\Http\Controllers\Member\RoleMemberController;
use App\Http\Controllers\Member\UserMemberController;

Route::prefix('member')->as('member.')->middleware(['auth', 'IsAccepted', 'user-access:member', 'verified', 'Language', 'IsActive'])->group(function () {
    Route::get('/home', [HomeMemberController::class, 'index'])->name('home');
    Route::get('/profile', [ProfileMemberController::class, 'index'])->name('profile');
    Route::post('/profile/update1', [ProfileMemberController::class, 'update1'])->name('profile.update1');
    Route::post('/profile/update2', [ProfileMemberController::class, 'update2'])->name('profile.update2');
    Route::post('/profile/update3', [ProfileMemberController::class, 'update3'])->name('profile.update3');
    Route::get('/profile/update4', [ProfileMemberController::class, 'update4'])->name('profile.update4');
    Route::resource('roles',  RoleMemberController::class);
    Route::post('/roles/update1', [RoleMemberController::class,'update1'])->name('roles.update1');
    Route::resource('users',  UserMemberController::class);
    Route::post('/users/update1', [UserMemberController::class,'update1'])->name('users.update1');
});
