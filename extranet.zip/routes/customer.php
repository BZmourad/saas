<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Customer\HomeCustomerController;
use App\Http\Controllers\Customer\ProfileCustomerController;

Route::prefix('customer')->as('customer.')->middleware(['auth', 'user-access:customer', 'verified', 'Language', 'IsActive'])->group(function () {
    Route::get('/home', [HomeCustomerController::class, 'index'])->name('home');
    Route::get('/profile', [ProfileCustomerController::class, 'index'])->name('profile');
    Route::post('/profile/update1', [ProfileCustomerController::class, 'update1'])->name('profile.update1');
    Route::post('/profile/update2', [ProfileCustomerController::class, 'update2'])->name('profile.update2');
    Route::post('/profile/update3', [ProfileCustomerController::class, 'update3'])->name('profile.update3');
    Route::get('/profile/update4', [ProfileCustomerController::class, 'update4'])->name('profile.update4');
});
