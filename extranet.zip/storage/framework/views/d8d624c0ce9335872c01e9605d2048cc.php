<!DOCTYPE html>
<html class="loading" data-textdirection="ltr">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title> <?php echo $__env->yieldContent('title'); ?> | <?php echo e(env('APP_NAME')); ?></title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="apple-touch-icon" href="<?php echo e(asset('storage/logo/'.config('app.favicon'))); ?>">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('storage/logo/'.config('app.favicon'))); ?>">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
        <?php echo $__env->make('customer.partials.main-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('style'); ?>
    </head>
    <body class="vertical-layout vertical-compact-menu <?php echo $__env->yieldContent('body_class'); ?> fixed-navbar" data-open="click" data-menu="vertical-compact-menu" data-col="<?php echo $__env->yieldContent('data_col'); ?>">

        <?php echo $__env->make('customer.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('customer.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="app-content content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('customer.partials.customizer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="sidenav-overlay"></div>
        <div class="drag-target"></div>
        <?php echo $__env->make('customer.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('customer.partials.main-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('script'); ?>
        <?php if(session()->has('errors')): ?>
            <script>
                $(document).ready(function() {
                    Swal.fire({
                        title:"<?php echo e(__('Error')); ?>!",
                        text:"<?php echo e(Session::get('errors')); ?>",
                        type:"error",
                        confirmButtonClass:"btn btn-primary",
                        buttonsStyling:!1
                    })
                });
            </script>
        <?php endif; ?>
        <?php if(session()->has('message')): ?>
            <script>
                $(document).ready(function() {
                    Swal.fire({
                        title:"<?php echo e(__('Operation successfully completed')); ?>!",
                        type:"success",
                        confirmButtonClass:"btn btn-primary",
                        buttonsStyling:!1
                    })
                });
            </script>
        <?php endif; ?>
        <?php if(auth()->user()->lang == 'fr'): ?>
            <script>
                jQuery.extend( jQuery.fn.pickadate.defaults, {
                    monthsFull: [ 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre' ],
                    monthsShort: [ 'Jan', 'Fev', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aou', 'Sep', 'Oct', 'Nov', 'Dec' ],
                    weekdaysFull: [ 'Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi' ],
                    weekdaysShort: [ 'Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam' ],
                    today: 'Aujourd\'hui',
                    clear: 'Effacer',
                    close: 'Fermer',
                    firstDay: 1,
                    format: 'dd mmmm yyyy',
                    formatSubmit: 'yyyy/mm/dd',
                    labelMonthNext:"Mois suivant",
                    labelMonthPrev:"Mois précédent",
                    labelMonthSelect:"Sélectionner un mois",
                    labelYearSelect:"Sélectionner une année"
                });
            </script>
        <?php endif; ?>
        <script>
            $(document).ready(function() {
                $(".select2").select2({dropdownAutoWidth:!0,width:"100%",placeholder:"<?php echo e(__('Choose an option')); ?>",allowClear:!0});
                $(".pickadate-selectors").pickadate({
                    selectMonths:!0,
                    selectYears:!0
                });
            });
        </script>
    </body>
</html>
<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/customer/layouts/app.blade.php ENDPATH**/ ?>