<?php if($data->hasAnyRole(\Spatie\Permission\Models\Role::all())): ?>
    <div class="badge block badge-striped border-right-teal badge-square text-center"> <?php echo e($data->getRoleNames()[0]); ?> </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/member/users/partials/role.blade.php ENDPATH**/ ?>