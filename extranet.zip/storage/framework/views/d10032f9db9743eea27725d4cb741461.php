<div class="btn-group btn-group-sm" role="group">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_members')): ?>
        <a class="btn btn-outline-info" href="<?php echo e(route('admin.members.edit',$data->id)); ?>"><i class="la la-edit"></i></a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_members')): ?>
        <button class="btn btn-outline-danger deleteData" type="button" data-id="<?php echo e($data->id); ?>"><i class="la la-trash"></i></button>
    <?php endif; ?>
    <?php
        $id = $data->id;
        $user = \App\Models\User::where('type', 1)->where('member_id',$data->id)->whereHas('roles', function ($q) use ($id) {
            $q->where('type', 1)->where('name', 'Admin')->where('member_id', $id);
        })->first();
    ?>
    <?php if($user->is_accepted == 0): ?>
        <button class="btn btn-outline-warning acceptData" type="button" data-id="<?php echo e($data->id); ?>" ><i class="la la-check-square-o"></i></button>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/admin/members/partials/action.blade.php ENDPATH**/ ?>