<div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_dashboard_member')): ?>
                <li class="nav-item <?php echo $__env->yieldContent('active_dashboard'); ?>"><a href="<?php echo e(route('member.home')); ?>" ><i class="la la-home"></i><span class="menu-title" ><?php echo e(__('Dashboard')); ?> </span></a></li>
            <?php endif; ?>
            <?php if(Gate::check('access_users_member') || Gate::check('access_roles_member') ): ?>
                <li class=" navigation-header"><span><?php echo e(__('Administrator')); ?></span><i class="la la-ellipsis-h" data-toggle="tooltip" data-placement="right" data-original-title="<?php echo e(__('Administrator')); ?>"></i></li>
                <?php if(Gate::check('access_users_member') || Gate::check('access_roles_member') ): ?>
                    <li class=" nav-item"><a href="#"><i class="la la-users"></i><span class="menu-title"><?php echo e(__('Manage Account')); ?></span></a>
                        <ul class="menu-content">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_users_member')): ?>
                                <li class="<?php echo $__env->yieldContent('active_users'); ?>"><a class="menu-item" href="<?php echo e(route('member.users.index')); ?>"> <span> <i class="icon-users"></i> <?php echo e(__('Users')); ?></span></a> </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_roles_member')): ?>
                                <li class="<?php echo $__env->yieldContent('active_roles'); ?>"><a class="menu-item" href="<?php echo e(route('member.roles.index')); ?>"> <span><i class="icon-key"></i> <?php echo e(__('Roles')); ?> </span></a> </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/member/partials/menu.blade.php ENDPATH**/ ?>