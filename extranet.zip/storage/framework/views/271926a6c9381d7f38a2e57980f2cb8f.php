<?php $__env->startSection('title'); ?>
    <?php echo e(__('Candidatures')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/datatable/datatables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/extensions/buttons.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/datatable/buttons.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/datatable/select.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/extensions/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/extensions/colReorder.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/extensions/fixedHeader.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/components.min.css')); ?>">
    <style>
        table.dataTable.no-footer {
            border-bottom: none !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active_candidature', 'active'); ?>
<?php $__env->startSection('data_col', '2-columns'); ?>
<?php $__env->startSection('body_class', '2-columns'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-overlay"></div>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block"><?php echo e(__('Candidatures')); ?></h3>
        </div>
        <div class="content-header-right col-md-6 col-12">
            <div class="btn-group float-md-right">
                <a class="btn btn-success round mb-1" role="button" disabled> <i class="la la-plus"></i> <?php echo e(__('Add')); ?></a>
            </div>
        </div>
    </div>
    <div class="content-body">
        <section id="constructor">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"> <?php echo e(__('Candidatures')); ?> </h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                            <div class="heading-elements">
                                <ul class="list-inline mb-0">
                                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-content collapse show">
                            <div class="card-body card-dashboard">
                                <table class="table table-striped table-bordered dataex-res-constructor">
                                    <thead class="text-uppercase text-center">
                                        <tr>
                                            <th><?php echo e(__('Company name')); ?></th>
                                            <th><?php echo e(__('Poste')); ?></th>
                                            <th><?php echo e(__('price')); ?></th>
                                            <th><?php echo e(__('Date')); ?></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/dataTables.colReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/dataTables.fixedHeader.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/datatable.min.js')); ?>"></script>
    <script>
        $(document).ready((function(){
            var columns = [
                {
                    targets: 0,
                    data: 'offer.company',
                    responsivePriority: 1,
                },
                {
                    targets: 1,
                    data: 'offer.title',
                },
                {
                    targets: 2,
                    data: 'offer.price',
                },
                {
                    targets: 3,
                    orderable: false,
                    searchable: false,
                    data: 'date',
                },
                {
                    targets: -1,
                    orderable: false,
                    searchable: false,
                    responsivePriority: 2,
                    data: 'action',
                }
            ];
            initdt(
                "/candidat/candidatures",
                "/i18n/dataTable/<?php echo e(auth::user()->lang); ?>.json",
                columns,
                "<?php echo e(__('Are you sure?')); ?>",
                "<?php echo e(__('You won’t be able to revert this!')); ?>",
                "<?php echo e(__('Yes, delete it!')); ?>",
                "<?php echo e(__('Cancelled')); ?>",
                '<?php echo e(csrf_token()); ?>',
                "<?php echo e(__('Error')); ?>!",
                "<?php echo e(__('Operation successfully completed')); ?>!",
                "<?php echo e(__('Data used')); ?>",
                "<?php echo e(__('Server Error')); ?>",
                "<?php echo e(__('rows')); ?>",
                "<?php echo e(__('Show all')); ?>",
                false
            );
        }));

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('candidat.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/candidat/candidature/index.blade.php ENDPATH**/ ?>