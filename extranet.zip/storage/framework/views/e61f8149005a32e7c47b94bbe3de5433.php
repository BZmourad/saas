<?php $__env->startSection('title'); ?>
    <?php echo e(__('Dashboard')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('active_dashboard', 'active'); ?>
<?php $__env->startSection('data_col', '2-columns'); ?>
<?php $__env->startSection('body_class', '2-columns'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row"></div>
        <div class="content-body">
            <?php
                $members = \App\Models\Member::get()->count();
                $candidat = \App\Models\Candidate::get()->count();
                $customers = \App\Models\Customer::get()->count();
            ?>
            <div class="row">
                <div class="col-xl-4 col-md-6 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media d-flex">
                                    <div class="align-self-center">
                                        <i class="la la-user-plus info font-large-2 float-left"></i>
                                    </div>
                                    <div class="media-body text-right">
                                        <h3><?php echo e($members); ?></h3>
                                        <span><?php echo e(__('Members')); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media d-flex">
                                    <div class="align-self-center">
                                        <i class="la la-users warning font-large-2 float-left"></i>
                                    </div>
                                    <div class="media-body text-right">
                                        <h3><?php echo e($customers); ?></h3>
                                        <span><?php echo e(__('Customers')); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media d-flex">
                                    <div class="align-self-center">
                                        <i class="icon-user success font-large-2 float-left"></i>
                                    </div>
                                    <div class="media-body text-right">
                                        <h3><?php echo e($candidat); ?></h3>
                                        <span><?php echo e(__('Candidates')); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/admin/home.blade.php ENDPATH**/ ?>