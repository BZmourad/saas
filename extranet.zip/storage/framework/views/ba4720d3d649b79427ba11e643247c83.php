<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>