<div class="btn-group btn-group-sm" role="group">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_offers')): ?>
        <a class="btn btn-outline-info" href="<?php echo e(route('admin.offers.edit',$data->id)); ?>"><i class="la la-edit"></i></a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_offers')): ?>
        <button class="btn btn-outline-danger deleteData" type="button" data-id="<?php echo e($data->id); ?>"><i class="la la-trash"></i></button>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/admin/offers/partials/action.blade.php ENDPATH**/ ?>