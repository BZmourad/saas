<?php if($data->is_active): ?>
    <span class="badge badge-success round block"> <?php echo e(__('Active')); ?> </span>
<?php else: ?>
    <span class="badge badge-danger round block"> <?php echo e(__('Inactive')); ?> </span>
<?php endif; ?>
<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/member/users/partials/status.blade.php ENDPATH**/ ?>