<div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_dashboard')): ?>
                <li class="nav-item <?php echo $__env->yieldContent('active_dashboard'); ?>"><a href="<?php echo e(route('admin.home')); ?>" ><i class="la la-home"></i><span class="menu-title" ><?php echo e(__('Dashboard')); ?> </span></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_countries')): ?>
                <li class="nav-item <?php echo $__env->yieldContent('active_countries'); ?>"><a href="<?php echo e(route('admin.countries.index')); ?>" ><i class="la la-globe"></i><span class="menu-title" ><?php echo e(__('Countries')); ?> </span></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("access_members")): ?>
                <li class="nav-item <?php echo $__env->yieldContent('active_members'); ?>"><a href="<?php echo e(route('admin.members.index')); ?>" ><i class="la la-user-plus"></i><span class="menu-title" ><?php echo e(__('Members')); ?> </span></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("access_customers")): ?>
                <li class="nav-item <?php echo $__env->yieldContent('active_customers'); ?>"><a href="<?php echo e(route('admin.customers.index')); ?>" ><i class="la la-users"></i><span class="menu-title" ><?php echo e(__('Customers')); ?> </span></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("access_offers")): ?>
                <li class="nav-item <?php echo $__env->yieldContent('active_offers'); ?>"><a href="<?php echo e(route('admin.offers.index')); ?>" ><i class="la la-paper-plane"></i><span class="menu-title" ><?php echo e(__('Offers')); ?> </span></a></li>
            <?php endif; ?>
            <?php if(Gate::check('access_users') || Gate::check('access_roles') ): ?>
                <li class=" navigation-header"><span><?php echo e(__('Administrator')); ?></span><i class="la la-ellipsis-h" data-toggle="tooltip" data-placement="right" data-original-title="<?php echo e(__('Administrator')); ?>"></i></li>
                <?php if(Gate::check('access_users') || Gate::check('access_roles') ): ?>
                    <li class=" nav-item"><a href="#"><i class="la la-users"></i><span class="menu-title"><?php echo e(__('Manage Account')); ?></span></a>
                        <ul class="menu-content">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_users')): ?>
                                <li class="<?php echo $__env->yieldContent('active_users'); ?>"><a class="menu-item" href="<?php echo e(route('admin.users.index')); ?>"> <span> <i class="icon-users"></i> <?php echo e(__('Users')); ?></span></a> </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_roles')): ?>
                                <li class="<?php echo $__env->yieldContent('active_roles'); ?>"><a class="menu-item" href="<?php echo e(route('admin.roles.index')); ?>"> <span><i class="icon-key"></i> <?php echo e(__('Roles')); ?> </span></a> </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/admin/partials/menu.blade.php ENDPATH**/ ?>