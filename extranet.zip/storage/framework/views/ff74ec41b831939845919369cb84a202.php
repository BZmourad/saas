<div class="btn-group btn-group-sm" role="group">
    <a class="btn btn-outline-info" role="button" disabled><i class="la la-edit"></i></a>
    <button class="btn btn-outline-danger deleteData" type="button" data-id="<?php echo e($data->id); ?>" disabled><i class="la la-trash"></i></button>
</div>
<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/candidat/candidature/partials/action.blade.php ENDPATH**/ ?>