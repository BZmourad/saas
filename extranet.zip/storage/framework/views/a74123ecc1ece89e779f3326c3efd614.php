<div class="media">
    <div class="media-left pr-1">
        <span class="avatar avatar-sm rounded-circle">
            <img src="<?php echo e(asset('storage/offers/'.$data->offer()->logo)); ?>" alt="avatar"><i></i>
        </span>
    </div>
    <div class="media-body media-middle">
        <a class="media-heading name"><?php echo e($data->offer()->company); ?></a>
    </div>
</div>


<?php /**PATH C:\laragon\www\_apps\extranet\_apps\extranet\resources\views/candidat/candidature/partials/name.blade.php ENDPATH**/ ?>