<!DOCTYPE html>
<html class="loading" data-textdirection="ltr">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title> {{ __('Login') }} | {{ env('APP_NAME') }}</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="apple-touch-icon" href="{{ asset('storage/logo/'.config('app.favicon')) }}">
        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('storage/logo/'.config('app.favicon')) }}">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/vendors.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/forms/icheck/icheck.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/forms/icheck/custom.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/bootstrap.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/bootstrap-extended.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/colors.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/components.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu-modern.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/colors/palette-gradient.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/pages/login-register.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style.css') }}">
        <style>
            #show-hide-password {
                cursor: pointer;
            }
            #branding_logo {
                max-width: 200px;
            }
        </style>
    </head>
    <body class="vertical-layout vertical-menu-modern 1-column  bg-full-screen-image blank-page" data-open="click" data-menu="vertical-menu-modern" data-col="1-column">
        <div class="app-content content">
            <div class="content-overlay"></div>
            <div class="content-wrapper">
                <div class="content-header row"></div>
                <div class="content-body">
                    <section class="row flexbox-container">
                        <div class="col-12 d-flex align-items-center justify-content-center">
                            <div class="col-lg-4 col-md-8 col-10 box-shadow-2 p-0">
                                <div class="card border-grey border-lighten-3 px-1 py-1 m-0">
                                    <div class="card-header border-0">
                                        <div class="card-title text-center">
                                            <img src="{{ asset('storage/logo/'.config('app.logo')) }}" alt="branding logo" id="branding_logo">
                                        </div>
                                    </div>
                                    <div class="card-content">
                                        <div class="card-body">
                                            @error('email')
                                                <div class="alert round bg-danger alert-icon-left alert-arrow-left alert-dismissible mb-2" role="alert">
                                                    <span class="alert-icon"><i class="la la-thumbs-o-down"></i></span>
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                            @error('password')
                                                <div class="alert round bg-danger alert-icon-left alert-arrow-left alert-dismissible mb-2" role="alert">
                                                    <span class="alert-icon"><i class="la la-thumbs-o-down"></i></span>
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                            <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                                                @csrf
                                                <fieldset class="form-group position-relative">
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text" ><i class="la la-envelope"></i></span>
                                                        </div>
                                                        <input type="email" class="form-control" id="user-name" placeholder="{{ __('Email Address') }}" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                                                    </div>
                                                </fieldset>
                                                <fieldset class="form-group position-relative">
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text" ><i class="la la-key"></i></span>
                                                        </div>
                                                        <input type="password" class="form-control" id="user-password" placeholder="{{ __('Password') }}" name="password" required autocomplete="current-password">
                                                        <div class="input-group-append">
                                                            <span class="input-group-text la la-eye" id="show-hide-password"></span>
                                                        </div>
                                                    </div>
                                                </fieldset>
                                                <div class="form-group row">
                                                    <div class="col-sm-8 col-12 text-center text-sm-left pr-0">
                                                        <fieldset>
                                                            <input type="checkbox" id="remember-me" class="chk-remember" name="remember" {{ old('remember') ? 'checked' : '' }}>
                                                            <label for="remember-me"> {{ __('Remember Me') }}</label>
                                                        </fieldset>
                                                    </div>
                                                    <div class="col-sm-4 col-12"></div>
                                                </div>
                                                <button type="submit" class="btn btn-outline-info btn-block"><i class="ft-unlock"></i> {{ __('Login') }}</button>
                                                <div class="form-group row">
                                                    <div class="col-sm-4 col-12 text-center text-sm-left pr-0"></div>
                                                    <div class="col-sm-8 col-12 float-sm-left text-center text-sm-right">
                                                        @if (Route::has('password.request'))
                                                            <a href="{{ route('password.request') }}" class="card-link">{{ __('Forgot Your Password?') }}</a>
                                                        @endif
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
        <script src="{{ asset('app-assets/vendors/js/vendors.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/forms/validation/jqBootstrapValidation.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/forms/icheck/icheck.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/core/app-menu.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/core/app.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/scripts/forms/form-login-register.min.js') }}"></script>
        <script>
            $(document).ready(function() {
                $("#show-hide-password").on('click', function() {
                    $(this).toggleClass("la-eye la-eye-slash");
                    var input = $("#user-password");
                    if (input.attr("type") === "password") {
                        input.attr("type", "text");
                    } else {
                        input.attr("type", "password");
                    }
                });
            });
        </script>
    </body>
</html>
