<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="nav-item @yield('active_dashboard')"><a href="{{ route('customer.home')}}" ><i class="la la-home"></i><span class="menu-title" >{{ __('Dashboard') }} </span></a></li>
        </ul>
    </div>
</div>
