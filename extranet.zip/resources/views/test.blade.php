<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>{{config('app.name')}}</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="apple-touch-icon" href="{{ asset('storage/logo/'.config('app.favicon')) }}">
        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('storage/logo/'.config('app.favicon')) }}">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/vendors.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/ui/prism.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/bootstrap.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/bootstrap-extended.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/colors.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/components.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu-modern.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/colors/palette-gradient.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style.css') }}">
        <style>
            .img-fluid{
                min-width: 100% !important;
                height: 400px !important;
            }
        </style>
    </head>
    <body class="vertical-layout vertical-menu-modern 1-column   fixed-navbar" data-open="click" data-menu="vertical-menu-modern" data-col="1-column">
        <nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-semi-dark navbar-shadow">
            <div class="navbar-wrapper">
                <div class="navbar-header">
                    <ul class="nav navbar-nav flex-row">
                        <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
                        <li class="nav-item">
                            <a class="navbar-brand" href="">
                                <img class="brand-logo" alt="modern admin logo" src="{{ asset('storage/logo/'.config('app.favicon')) }}">
                                <h3 class="brand-text">{{config('app.name')}}</h3>
                            </a>
                        </li>
                        <li class="nav-item d-md-none"><a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v"></i></a></li>
                    </ul>
                </div>
                <div class="navbar-container content">
                    <div class="collapse navbar-collapse" id="navbar-mobile">
                        <ul class="nav navbar-nav mr-auto float-left">
                            <li class="nav-item d-none d-md-block"><a class="nav-link nav-link-expand" href="#"><i class="ficon ft-maximize"></i></a></li>
                        </ul>
                        <ul class="nav navbar-nav float-right">
                            @auth
                                <li class="nav-item d-none d-md-block"><a class="nav-link" href="{{ url('/home') }}"><i class="la la-home"></i> {{ __('Dashboard')}} </a></li>
                            @else
                                <li class="nav-item d-none d-md-block"><a class="nav-link" href="{{ route('login') }}"><i class="la la-sign-in"></i> {{ __('Log in')}} </a></li>
                                <li class="nav-item d-none d-md-block"><a class="nav-link" href="{{ route('register') }}"><i class="la la-user-plus"></i> {{ __('Register')}} </a></li>
                            @endauth
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        <div class="app-content content">
            <div class="content-overlay"></div>
            <div class="content-wrapper">
                <div class="content-body">
                    <section class="container mt-3 mb-3">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
							<ol class="carousel-indicators">
								<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
								<li data-target="#carousel-example-generic" data-slide-to="1"></li>
								<li data-target="#carousel-example-generic" data-slide-to="2"></li>
							</ol>
							<div class="carousel-inner" role="listbox">
								<div class="carousel-item active">
									<img src="{{ asset('app-assets/images/carousel/02.jpg') }}" class="img-fluid" alt="First slide">
								</div>
								<div class="carousel-item">
									<img src="{{ asset('app-assets/images/carousel/03.jpg') }}" class="img-fluid" alt="Second slide">
								</div>
								<div class="carousel-item">
									<img src="{{ asset('app-assets/images/carousel/01.jpg') }}" class="img-fluid" alt="Third slide">
								</div>
							</div>
							<a class="carousel-control-prev" href="#carousel-example-generic" role="button" data-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							</a>
							<a class="carousel-control-next" href="#carousel-example-generic" role="button" data-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							</a>
						</div>
                    </section>
                    <section class="container">
                        <div class="row match-height">
                            @foreach (\App\Models\Offer::get() as $item)
                                <div class="col-xl-3 col-md-6 col-sm-12">
                                    <div class="card">
                                        <div class="card-content">
                                            <div class="card-body">
                                                <h4 class="card-title"> <i class="la la-building"></i> {{ $item->company}}</h4>
                                                <h6 class="card-subtitle text-muted"><i class="la la-pencil"></i> {{ $item->title}}</h6>
                                            </div>
                                            <img class="img-fluid" src="{{ asset('storage/offers/'.$item->logo) }}" alt="{{ $item->company}}">
                                            <div class="card-body">
                                                <p class="card-text"> <i class="la la-tags"></i> {{ $item->experience}}</p>
                                                <a href="#" class="btn btn-outline-teal">{{ __('Apply for a job')}}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </section>
                </div>
            </div>
        </div>
        <div class="sidenav-overlay"></div>
        <div class="drag-target"></div>
        <footer class="footer footer-static footer-light navbar-border navbar-shadow">
            <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2024 <a class="text-bold-800 grey darken-2" href="" >WebChallenge</a></span><span class="float-md-right d-none d-lg-block">Hand-crafted & Made with<i class="ft-heart pink"></i><span id="scroll-top"></span></span></p>
        </footer>
        <script src="{{ asset('app-assets/vendors/js/vendors.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/ui/prism.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/core/app-menu.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/core/app.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/scripts/customizer.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/scripts/footer.min.js') }}"></script>
    </body>
</html>
