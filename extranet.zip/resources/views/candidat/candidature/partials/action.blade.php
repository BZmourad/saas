<div class="btn-group btn-group-sm" role="group">
    <a class="btn btn-outline-info" role="button" disabled><i class="la la-edit"></i></a>
    <button class="btn btn-outline-danger deleteData" type="button" data-id="{{$data->id}}" disabled><i class="la la-trash"></i></button>
</div>
