<!DOCTYPE html>
<html class="loading" data-textdirection="ltr">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title> @yield('title') | {{ env('APP_NAME') }}</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="apple-touch-icon" href="{{ asset('storage/logo/'.config('app.favicon')) }}">
        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('storage/logo/'.config('app.favicon')) }}">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
        @include('candidat.partials.main-css')
        @yield('style')
    </head>
    <body class="vertical-layout vertical-compact-menu @yield('body_class') fixed-navbar" data-open="click" data-menu="vertical-compact-menu" data-col="@yield('data_col')">

        @include('candidat.partials.header')
        @include('candidat.partials.menu')
        <div class="app-content content">
            @yield('content')
        </div>
        @include('candidat.partials.customizer')
        <div class="sidenav-overlay"></div>
        <div class="drag-target"></div>
        @include('candidat.partials.footer')
        @include('candidat.partials.main-js')
        @yield('script')
        @if(session()->has('errors'))
            <script>
                $(document).ready(function() {
                    Swal.fire({
                        title:"{{ __('Error')}}!",
                        text:"{{Session::get('errors') }}",
                        type:"error",
                        confirmButtonClass:"btn btn-primary",
                        buttonsStyling:!1
                    })
                });
            </script>
        @endif
        @if(session()->has('message'))
            <script>
                $(document).ready(function() {
                    Swal.fire({
                        title:"{{ __('Operation successfully completed') }}!",
                        type:"success",
                        confirmButtonClass:"btn btn-primary",
                        buttonsStyling:!1
                    })
                });
            </script>
        @endif
        @if (auth()->user()->lang == 'fr')
            <script>
                jQuery.extend( jQuery.fn.pickadate.defaults, {
                    monthsFull: [ 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre' ],
                    monthsShort: [ 'Jan', 'Fev', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aou', 'Sep', 'Oct', 'Nov', 'Dec' ],
                    weekdaysFull: [ 'Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi' ],
                    weekdaysShort: [ 'Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam' ],
                    today: 'Aujourd\'hui',
                    clear: 'Effacer',
                    close: 'Fermer',
                    firstDay: 1,
                    format: 'dd mmmm yyyy',
                    formatSubmit: 'yyyy/mm/dd',
                    labelMonthNext:"Mois suivant",
                    labelMonthPrev:"Mois précédent",
                    labelMonthSelect:"Sélectionner un mois",
                    labelYearSelect:"Sélectionner une année"
                });
            </script>
        @endif
        <script>
            $(document).ready(function() {
                $(".select2").select2({dropdownAutoWidth:!0,width:"100%",placeholder:"{{ __('Choose an option')}}",allowClear:!0});
                $(".pickadate-selectors").pickadate({
                    selectMonths:!0,
                    selectYears:!0
                });
            });
        </script>
    </body>
</html>
