<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>{{config('app.name')}}</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="apple-touch-icon" href="{{ asset('storage/logo/'.config('app.favicon')) }}">
        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('storage/logo/'.config('app.favicon')) }}">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/vendors.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/ui/prism.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/bootstrap.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/bootstrap-extended.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/colors.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/components.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu-modern.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/colors/palette-gradient.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/plugins/forms/wizard.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/forms/selects/select2.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/pickers/daterange/daterangepicker.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/pickers/pickadate/pickadate.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/plugins/pickers/daterange/daterange.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/extensions/sweetalert2.min.css') }}">
        <style>
            #show-hide-password {
                cursor: pointer;
            }
            #show-hide-passwordconfirm {
                cursor: pointer;
            }
            #branding_logo {
                max-width: 200px;
            }
        </style>
    </head>
    <body class="vertical-layout vertical-menu-modern 1-column   fixed-navbar" data-open="click" data-menu="vertical-menu-modern" data-col="1-column">
        <nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-semi-dark navbar-shadow">
            <div class="navbar-wrapper">
                <div class="navbar-header">
                    <ul class="nav navbar-nav flex-row">
                        <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
                        <li class="nav-item">
                            <a class="navbar-brand" href="">
                                <img class="brand-logo" alt="modern admin logo" src="{{ asset('storage/logo/'.config('app.favicon')) }}">
                                <h3 class="brand-text">{{config('app.name')}}</h3>
                            </a>
                        </li>
                        <li class="nav-item d-md-none"><a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v"></i></a></li>
                    </ul>
                </div>
                <div class="navbar-container content">
                    <div class="collapse navbar-collapse" id="navbar-mobile">
                        <ul class="nav navbar-nav mr-auto float-left">
                            <li class="nav-item d-none d-md-block"><a class="nav-link nav-link-expand" href="#"><i class="ficon ft-maximize"></i></a></li>
                        </ul>
                        <ul class="nav navbar-nav float-right">
                            @auth
                                <li class="nav-item d-none d-md-block"><a class="nav-link" href="{{ url('/home') }}"><i class="la la-home"></i> {{ __('Dashboard')}} </a></li>
                            @else
                                <li class="nav-item d-none d-md-block"><a class="nav-link" href="{{ route('login') }}"><i class="la la-sign-in"></i> {{ __('Log in')}} </a></li>
                                <li class="nav-item d-none d-md-block"><a class="nav-link" href="{{ route('register') }}"><i class="la la-user-plus"></i> {{ __('Register')}} </a></li>
                            @endauth
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        <div class="app-content content">
            <div class="content-overlay"></div>
            <div class="content-wrapper">
                <div class="content-body">
                    <section class="container mt-3 mb-3">
                        <div class="card border-grey border-lighten-3 px-1 py-1 m-0">
                            <div class="card-content">
                                <div class="card-body" >
                                    <form class="steps-validation wizard-circle" method="POST" action="{{ route('candidature') }}" enctype="multipart/form-data">
                                        @csrf
                                        <h6><i class="step-icon la la-pencil"></i> {{ __('Step')}} 1</h6>
                                        <fieldset>
                                            <input type="hidden" name="offer_id" value="{{$offer->id}}">
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control">{{ __('Select A New Photo') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <label id="projectinput8" class="file center-block">
                                                        <input type="file" id="file" name="image" >
                                                        <span class="file-custom"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="firstname">{{ __('firstname') }} <span class="text-danger">*</span> </label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="firstname" class="form-control" placeholder="{{ __('firstname') }}" name="firstname" value="{{ old('firstname') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-pencil"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="lastname">{{ __('lastname') }} <span class="text-danger">*</span> </label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="lastname" class="form-control" placeholder="{{ __('lastname') }}" name="lastname" value="{{ old('lastname') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-pencil"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="birthday">{{ __('birthday') }} <span class="text-danger">*</span> </label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="input-group">
                                                        <input type="text" id="birthday" class="form-control pickadate-selectors" placeholder="{{ __('birthday') }}" name="birthday" value="{{ old('birthday') }}">
                                                        <div class="input-group-append"><span class="input-group-text"><span class="la la-calendar-o"></span></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="job">{{ __('job') }} <span class="text-danger">*</span> </label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="job" class="form-control" placeholder="{{ __('job') }}" name="job" value="{{ old('job') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-tag"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="description">{{ __('Description') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <textarea id="description" rows="5" class="form-control" placeholder="{{ __('Description') }}" name="description" >{{old('description')}}</textarea>
                                                        <div class="form-control-position">
                                                            <i class="la la-pencil"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <h6><i class="step-icon la la-map-marker"></i>{{ __('Step')}} 2</h6>
                                        <fieldset>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="address">{{ __('Address') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <textarea id="address" rows="5" class="form-control" placeholder="{{ __('Address') }}" name="address" >{{old('address')}}</textarea>
                                                        <div class="form-control-position">
                                                            <i class="la la-map-marker"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="city">{{ __('City') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="city" class="form-control" placeholder="{{ __('City') }}" name="city" value="{{ old('city') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-map-signs"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="country_id">{{ __('Country') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <select class="select2 form-control" name="country_id">
                                                        <option value=""></option>
                                                        @foreach(\App\Models\Country::get() as $item)
                                                            <option value="{{ $item->id }}" @if(old('country_id') == $item->id) selected @endif>{{ $item->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="postal_code">{{ __('Postal code') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="postal_code" class="form-control postal_code-mask" placeholder="{{ __('Postal code') }}" name="postal_code" value="{{ old('postal_code') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-location-arrow"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <h6><i class="step-icon la la-map-signs"></i>{{ __('Step')}} 3</h6>
                                        <fieldset>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="phone">{{ __('phone') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="phone" class="form-control phone-mask" placeholder="{{ __('phone') }}" name="phone" value="{{ old('phone') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-phone"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="facebook">{{ __('facebook') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="facebook" class="form-control" placeholder="{{ __('facebook') }}" name="facebook" value="{{ old('facebook') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-facebook"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="whatsapp">{{ __('whatsapp') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="whatsapp" class="form-control" placeholder="{{ __('whatsapp') }}" name="whatsapp" value="{{ old('whatsapp') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-whatsapp"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="skype">{{ __('skype') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="skype" class="form-control" placeholder="{{ __('skype') }}" name="skype" value="{{ old('skype') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-skype"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-3 label-control" for="twitter">{{ __('twitter') }}</label>
                                                <div class="col-md-9 mx-auto">
                                                    <div class="position-relative has-icon-left">
                                                        <input type="text" id="twitter" class="form-control" placeholder="{{ __('twitter') }}" name="twitter" value="{{ old('twitter') }}">
                                                        <div class="form-control-position">
                                                            <i class="la la-twitter"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <h6><i class="step-icon la la-key"></i>{{ __('Step')}} 4</h6>
                                        <fieldset>
                                            <fieldset class="form-group position-relative">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" ><i class="la la-user"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control" id="user-name" placeholder="{{ __('Name') }}" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group position-relative">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" ><i class="la la-envelope"></i></span>
                                                    </div>
                                                    <input type="email" class="form-control" id="user-email" placeholder="{{ __('Email Address') }}" name="email" value="{{ old('email') }}" required autocomplete="email">
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group position-relative">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" ><i class="la la-key"></i></span>
                                                    </div>
                                                    <input type="password" class="form-control" id="user-password" placeholder="{{ __('Password') }}" name="password" required autocomplete="new-password">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text la la-eye" id="show-hide-password"></span>
                                                    </div>
                                                </div>
                                            </fieldset>
                                            <fieldset class="form-group position-relative">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" ><i class="la la-key"></i></span>
                                                    </div>
                                                    <input type="password" class="form-control" id="user-passwordconfirm" placeholder="{{ __('Confirm Password') }}" name="password_confirmation" required autocomplete="new-password">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text la la-eye" id="show-hide-passwordconfirm"></span>
                                                    </div>
                                                </div>
                                            </fieldset>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
        <div class="sidenav-overlay"></div>
        <div class="drag-target"></div>
        <footer class="footer footer-static footer-light navbar-border navbar-shadow">
            <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2024 <a class="text-bold-800 grey darken-2" href="" >WebChallenge</a></span><span class="float-md-right d-none d-lg-block">Hand-crafted & Made with<i class="ft-heart pink"></i><span id="scroll-top"></span></span></p>
        </footer>
        <script src="{{ asset('app-assets/vendors/js/vendors.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/ui/prism.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/core/app-menu.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/core/app.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/scripts/customizer.min.js') }}"></script>
        <script src="{{ asset('app-assets/js/scripts/footer.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/forms/select/select2.full.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/extensions/jquery.steps.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/forms/validation/jquery.validate.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/pickers/pickadate/picker.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/pickers/pickadate/picker.date.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/pickers/pickadate/picker.time.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/pickers/pickadate/legacy.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/forms/extended/inputmask/jquery.inputmask.bundle.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/extensions/sweetalert2.all.min.js') }}"></script>
        @if(session()->has('errors'))
            <script>
                $(document).ready(function() {
                    Swal.fire({
                        title:"{{ __('Error')}}!",
                        text:"{{Session::get('errors') }}",
                        type:"error",
                        confirmButtonClass:"btn btn-primary",
                        buttonsStyling:!1
                    })
                });
            </script>
        @endif
        @if(session()->has('message'))
            <script>
                $(document).ready(function() {
                    Swal.fire({
                        title:"{{ __('Operation successfully completed') }}!",
                        type:"success",
                        confirmButtonClass:"btn btn-primary",
                        buttonsStyling:!1
                    })
                });
            </script>
        @endif
        <script>
            var form=$(".steps-validation").show();
            $(".steps-validation").steps({
                headerTag:"h6",
                bodyTag:"fieldset",
                transitionEffect:"fade",
                titleTemplate:'<span class="step">#index#</span> #title#',
                labels:{finish:"Submit"},
                onStepChanging:function(e,t,i){return t>i||!(3===i&&Number($("#age-2").val())<18)&&(t<i&&(form.find(".body:eq("+i+") label.error").remove(),form.find(".body:eq("+i+") .error").removeClass("error")),form.validate().settings.ignore=":disabled,:hidden",form.valid())},
                onFinishing:function(e,t){return form.validate().settings.ignore=":disabled",form.valid()},
                onFinished:function(e,t){$( ".steps-validation" ).trigger( "submit" );}
            });
            $(".steps-validation").validate({
                ignore:"input[type=hidden]",
                errorClass:"danger",
                successClass:"success",
                highlight:function(e,t){$(e).removeClass(t)},
                unhighlight:function(e,t){$(e).removeClass(t)},
                errorPlacement:function(e,t){e.insertAfter(t)},
                rules:{email:{email:!0}}
            });
        </script>
        <script>
            jQuery.extend( jQuery.fn.pickadate.defaults, {
                monthsFull: [ 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre' ],
                monthsShort: [ 'Jan', 'Fev', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aou', 'Sep', 'Oct', 'Nov', 'Dec' ],
                weekdaysFull: [ 'Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi' ],
                weekdaysShort: [ 'Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam' ],
                today: 'Aujourd\'hui',
                clear: 'Effacer',
                close: 'Fermer',
                firstDay: 1,
                format: 'yyyy-mm-dd',
                formatSubmit: 'yyyy-mm-dd',
                labelMonthNext:"Mois suivant",
                labelMonthPrev:"Mois précédent",
                labelMonthSelect:"Sélectionner un mois",
                labelYearSelect:"Sélectionner une année"
            });
        </script>
        <script>
            $(document).ready(function() {
                $(".select2").select2({dropdownAutoWidth:!0,width:"100%",placeholder:"{{ __('Choose an option')}}",allowClear:!0});
                $('.phone-mask').inputmask('(999) 999-9999');
                $(".pickadate-selectors").pickadate({
                    selectMonths:!0,
                    selectYears:!0
                });
                $("#show-hide-password").on('click', function() {
                    $(this).toggleClass("la-eye la-eye-slash");
                    var input = $("#user-password");
                    if (input.attr("type") === "password") {
                        input.attr("type", "text");
                    } else {
                        input.attr("type", "password");
                    }
                });
                $("#show-hide-passwordconfirm").on('click', function() {
                    $(this).toggleClass("la-eye la-eye-slash");
                    var input = $("#user-passwordconfirm");
                    if (input.attr("type") === "password") {
                        input.attr("type", "text");
                    } else {
                        input.attr("type", "password");
                    }
                });
            });
        </script>
    </body>
</html>
