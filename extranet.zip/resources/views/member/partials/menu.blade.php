<div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            @can('access_dashboard_member')
                <li class="nav-item @yield('active_dashboard')"><a href="{{ route('member.home')}}" ><i class="la la-home"></i><span class="menu-title" >{{ __('Dashboard') }} </span></a></li>
            @endcan
            @if(Gate::check('access_users_member') || Gate::check('access_roles_member') )
                <li class=" navigation-header"><span>{{ __('Administrator')}}</span><i class="la la-ellipsis-h" data-toggle="tooltip" data-placement="right" data-original-title="{{ __('Administrator')}}"></i></li>
                @if(Gate::check('access_users_member') || Gate::check('access_roles_member') )
                    <li class=" nav-item"><a href="#"><i class="la la-users"></i><span class="menu-title">{{ __('Manage Account')}}</span></a>
                        <ul class="menu-content">
                            @can('access_users_member')
                                <li class="@yield('active_users')"><a class="menu-item" href="{{ route('member.users.index') }}"> <span> <i class="icon-users"></i> {{ __('Users') }}</span></a> </li>
                            @endcan
                            @can('access_roles_member')
                                <li class="@yield('active_roles')"><a class="menu-item" href="{{ route('member.roles.index') }}"> <span><i class="icon-key"></i> {{ __('Roles') }} </span></a> </li>
                            @endcan
                        </ul>
                    </li>
                @endif
            @endif
        </ul>
    </div>
</div>
