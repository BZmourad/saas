@extends('member.layouts.app')

@section('title')
    {{ __('Users') }}
@endsection

@section('style')
    <style>
        #show-hide-password {
            cursor: pointer;
        }
        #show-hide-passwordconfirm {
            cursor: pointer;
        }
    </style>
@endsection

@section('active_users', 'active')
@section('data_col', '2-columns')
@section('body_class', '2-columns')

@section('content')
<div class="content-overlay"></div>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">{{ __('Administrator')}}</h3>
            <div class="row breadcrumbs-top d-inline-block">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">{{ __('Manage Account')}}</li>
                        <li class="breadcrumb-item"><a href="{{route('member.users.index')}}">{{ __('Users')}}</a></li>
                        <li class="breadcrumb-item active">{{ __('Add')}}</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-header-right col-md-6 col-12"></div>
    </div>
    <div class="content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-icons"></h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <form class="form form-horizontal" action="{{ route('member.users.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="form-body">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control">{{ __('Select A New Photo') }}</label>
                                        <div class="col-md-9 mx-auto">
                                            <label id="projectinput8" class="file center-block">
                                                <input type="file" id="file" name="image" >
                                                <span class="file-custom"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="role">{{ __('Role')}}</label>
                                        <div class="col-md-9 mx-auto">
                                            <select class="select2 form-control" name="role">
                                                <option value=""></option>
                                                @foreach(\Spatie\Permission\Models\Role::where('type', 1)->where('member_id',getMember()->id)->get() as $role)
                                                    <option value="{{ $role->name }}" @if(old('role') == $role->name) selected @endif>{{ $role->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="name">{{ __('Name') }}</label>
                                        <div class="col-md-9 mx-auto">
                                            <div class="position-relative has-icon-left">
                                                <input type="text" id="name" class="form-control" placeholder="{{ __('Name') }}" name="name" value="{{ old('name') }}">
                                                <div class="form-control-position">
                                                    <i class="la la-user"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="email">{{ __('Email Address') }}</label>
                                        <div class="col-md-9 mx-auto">
                                            <div class="position-relative has-icon-left">
                                                <input type="email" id="email" class="form-control" placeholder="{{ __('Email Address') }}" name="email" value="{{ old('email') }}">
                                                <div class="form-control-position">
                                                    <i class="la la-envelope"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="password">{{ __('Password') }}</label>
                                        <div class="col-md-9 mx-auto">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" ><i class="la la-key"></i></span>
                                                </div>
                                                <input type="password" class="form-control" id="password" placeholder="{{ __('Password') }}" name="password" >
                                                <div class="input-group-append">
                                                    <span class="input-group-text la la-eye" id="show-hide-password"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="password_confirmation">{{ __('Confirm Password') }}</label>
                                        <div class="col-md-9 mx-auto">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" ><i class="la la-key"></i></span>
                                                </div>
                                                <input type="password" class="form-control" id="password_confirmation" placeholder="{{ __('Confirm Password') }}" name="password_confirmation" >
                                                <div class="input-group-append">
                                                    <span class="input-group-text la la-eye" id="show-hide-passwordconfirm"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control"></label>
                                        <div class="col-md-9 mx-auto">
                                            <div class="input-group">
                                                <div class="d-inline-block custom-control custom-checkbox mr-1">
                                                    <input type="checkbox" name="user_send_email" class="custom-control-input" checked id="user_send_email">
                                                    <label class="custom-control-label" for="user_send_email">{{ __('Send access parameters by email')}}</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-actions text-center">
                                    <button type="reset" class="btn btn-warning mr-1">
                                        <i class="ft-x"></i> {{ __('Cancel')}}
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="la la-check-square-o"></i> {{ __('Save')}}
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
    $(document).ready(function() {
        $("#show-hide-password").on('click', function() {
            $(this).toggleClass("la-eye la-eye-slash");
            var input = $("#password");
            if (input.attr("type") === "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });
        $("#show-hide-passwordconfirm").on('click', function() {
            $(this).toggleClass("la-eye la-eye-slash");
            var input = $("#password_confirmation");
            if (input.attr("type") === "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });
    });
</script>
@endsection
