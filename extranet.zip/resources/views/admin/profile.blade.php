@extends('admin.layouts.app')

@section('title')
    {{ __('Profile') }}
@endsection

@section('style')
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/forms/selects/select2.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/pickers/pickadate/pickadate.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/forms/toggle/switchery.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/plugins/forms/validation/form-validation.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/plugins/pickers/daterange/daterange.min.css') }}">


@endsection

@section('data_col', '2-columns')
@section('body_class', '2-columns')

@section('content')
<div class="content-overlay"></div>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">{{ __('Profile')}}</h3>
        </div>
        <div class="content-header-right col-md-6 col-12"></div>
    </div>
    <div class="content-body">
        <section id="page-account-settings">
            <div class="row">
                <div class="col-md-3 mb-2 mb-md-0">
                    <ul class="nav nav-pills flex-column mt-md-0 mt-1">
                        <li class="nav-item">
                            <a class="nav-link d-flex active" id="account-pill-general" data-toggle="pill"
                                href="#account-vertical-general" aria-expanded="true">
                                <i class="ft-globe mr-50"></i>
                                {{ __('Profile Information')}}
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link d-flex" id="account-pill-password" data-toggle="pill" href="#account-vertical-password"
                                aria-expanded="false">
                                <i class="ft-lock mr-50"></i>
                                {{ __('Update Password')}}
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link d-flex" id="account-pill-info" data-toggle="pill" href="#account-vertical-info"
                                aria-expanded="false">
                                <i class="ft-camera mr-50"></i>
                                {{ __('Update Profile Picture')}}
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane active" id="account-vertical-general" aria-labelledby="account-pill-general" aria-expanded="true">
                                        <form  autocomplete="off" method="POST" action="{{route('admin.profile.update1')}}">
                                            @csrf
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <div class="controls">
                                                            <label for="account-username">{{ __('Name')}}</label>
                                                            <input type="text" class="form-control" id="account-username" placeholder="{{ __('Name')}}" required name="name" value="{{Auth::user()->name}}">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <div class="controls">
                                                            <label for="account-e-mail">{{ __('Email')}}</label>
                                                            <input type="email" class="form-control" id="account-e-mail" placeholder="{{ __('Email')}}" required value="{{Auth::user()->email}}" name="email" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label for="languageselect2">{{ __('Languages')}}</label>
                                                        <select class="form-control" id="languageselect2" name="lang">
                                                            <option value="en" @if (Auth::user()->lang == 'en') selected @endif>{{ __('English')}}</option>
                                                            <option value="fr" @if (Auth::user()->lang == 'fr') selected @endif>{{ __('French')}}</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                                    <button type="submit" class="btn btn-primary mr-sm-1 mb-1 mb-sm-0"> {{ __('Save')}} </button>
                                                    <button type="reset" class="btn btn-light">{{ __('Cancel')}}</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade " id="account-vertical-password" role="tabpanel" aria-labelledby="account-pill-password" aria-expanded="false">
                                        <form autocomplete="off" enctype="multipart/form-data" method="POST" action="{{route('admin.profile.update3')}}">
                                            @csrf
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <div class="controls">
                                                            <label for="account-old-password">{{ __('Current Password') }}</label>
                                                            <input type="password" class="form-control" id="account-old-password" required placeholder="{{ __('Current Password') }}" name="current_password" autocomplete="current_password">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <div class="controls">
                                                            <label for="account-new-password">{{ __('New Password') }}</label>
                                                            <input type="password" id="account-new-password" class="form-control" placeholder="{{ __('New Password') }}" required name="password" autocomplete="password">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <div class="controls">
                                                            <label for="account-retype-new-password">{{ __('Confirm Password') }}</label>
                                                            <input type="password" class="form-control" required id="account-retype-new-password" name="password_confirmation" autocomplete="password_confirmation" placeholder="{{ __('Confirm Password') }}" name="password_confirmation" autocomplete="password_confirmation" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                                    <button type="submit" class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">{{ __('Save')}}</button>
                                                    <button type="reset" class="btn btn-light">{{ __('Cancel')}}</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="account-vertical-info" role="tabpanel" aria-labelledby="account-pill-info" aria-expanded="false">
                                        <form  method="POST" action="{{route('admin.profile.update2')}}" autocomplete="off" enctype="multipart/form-data" class="dropzone overflow-visible p-0" id="formDropzone" novalidate>
                                            @csrf
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <div class="controls">
                                                            <label for="account-old-password">{{ __('Select A New Photo') }}</label>
                                                            <input type="file" class="form-control" required name="image" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                                    <button type="submit" class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">{{ __('Save')}}</button>
                                                    <button type="reset" class="btn btn-light">{{ __('Cancel')}}</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
@endsection

@section('script')
    <script src="{{ asset('app-assets/vendors/js/forms/select/select2.full.min.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/forms/validation/jqBootstrapValidation.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/pickers/pickadate/picker.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/pickers/pickadate/picker.date.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/forms/toggle/switchery.min.js') }}"></script>
@endsection
