@if($data->is_active)
    <span class="badge badge-success round block"> {{ __('Active')}} </span>
@else
    <span class="badge badge-danger round block"> {{ __('Inactive')}} </span>
@endif
