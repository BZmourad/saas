@if ($data->hasAnyRole(\Spatie\Permission\Models\Role::all()))
    <div class="badge block badge-striped border-right-teal badge-square text-center"> {{$data->getRoleNames()[0]}} </div>
@endif
