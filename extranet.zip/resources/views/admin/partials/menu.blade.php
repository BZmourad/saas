<div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            @can('access_dashboard')
                <li class="nav-item @yield('active_dashboard')"><a href="{{ route('admin.home')}}" ><i class="la la-home"></i><span class="menu-title" >{{ __('Dashboard') }} </span></a></li>
            @endcan
            @can('access_countries')
                <li class="nav-item @yield('active_countries')"><a href="{{ route('admin.countries.index')}}" ><i class="la la-globe"></i><span class="menu-title" >{{ __('Countries') }} </span></a></li>
            @endcan
            @can("access_members")
                <li class="nav-item @yield('active_members')"><a href="{{ route('admin.members.index')}}" ><i class="la la-user-plus"></i><span class="menu-title" >{{ __('Members') }} </span></a></li>
            @endcan
            @can("access_customers")
                <li class="nav-item @yield('active_customers')"><a href="{{ route('admin.customers.index')}}" ><i class="la la-users"></i><span class="menu-title" >{{ __('Customers') }} </span></a></li>
            @endcan
            @can("access_offers")
                <li class="nav-item @yield('active_offers')"><a href="{{ route('admin.offers.index')}}" ><i class="la la-paper-plane"></i><span class="menu-title" >{{ __('Offers') }} </span></a></li>
            @endcan
            @if(Gate::check('access_users') || Gate::check('access_roles') )
                <li class=" navigation-header"><span>{{ __('Administrator')}}</span><i class="la la-ellipsis-h" data-toggle="tooltip" data-placement="right" data-original-title="{{ __('Administrator')}}"></i></li>
                @if(Gate::check('access_users') || Gate::check('access_roles') )
                    <li class=" nav-item"><a href="#"><i class="la la-users"></i><span class="menu-title">{{ __('Manage Account')}}</span></a>
                        <ul class="menu-content">
                            @can('access_users')
                                <li class="@yield('active_users')"><a class="menu-item" href="{{ route('admin.users.index') }}"> <span> <i class="icon-users"></i> {{ __('Users') }}</span></a> </li>
                            @endcan
                            @can('access_roles')
                                <li class="@yield('active_roles')"><a class="menu-item" href="{{ route('admin.roles.index') }}"> <span><i class="icon-key"></i> {{ __('Roles') }} </span></a> </li>
                            @endcan
                        </ul>
                    </li>
                @endif
            @endif
        </ul>
    </div>
</div>
