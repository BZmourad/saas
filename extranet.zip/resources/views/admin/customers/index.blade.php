@extends('admin.layouts.app')

@section('title')
    {{ __('Customers') }}
@endsection

@section('style')
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/extensions/buttons.dataTables.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/datatable/buttons.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/datatable/select.dataTables.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/extensions/responsive.dataTables.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/extensions/colReorder.dataTables.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/extensions/fixedHeader.dataTables.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/components.min.css') }}">
    <style>
        table.dataTable.no-footer {
            border-bottom: none !important;
        }
    </style>
@endsection

@section('active_customers', 'active')
@section('data_col', '2-columns')
@section('body_class', '2-columns')

@section('content')
<div class="content-overlay"></div>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">{{ __('Customers')}}</h3>
            <div class="row breadcrumbs-top d-inline-block"></div>
        </div>
        <div class="content-header-right col-md-6 col-12">
            @can('add_customers')
                <div class="btn-group float-md-right">
                    <a class="btn btn-success round mb-1" href="{{route('admin.customers.create')}}"> <i class="la la-plus"></i> {{ __('Add')}}</a>
                </div>
            @endcan
        </div>
    </div>
    <div class="content-body">
        <section id="constructor">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"> {{ __('List of customers')}} </h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                            <div class="heading-elements">
                                <ul class="list-inline mb-0">
                                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-content collapse show">
                            <div class="card-body card-dashboard">
                                <table class="table table-striped table-bordered dataex-res-constructor">
                                    <thead class="text-uppercase text-center">
                                        <tr>
                                            <th>{{ __('Name')}}</th>
                                            <th>{{ __('Address')}}</th>
                                            <th>{{ __('Country')}}</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
@endsection

@section('script')
    <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/tables/buttons.colVis.min.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/tables/datatable/dataTables.colReorder.min.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('app-assets/vendors/js/tables/datatable/dataTables.fixedHeader.min.js') }}"></script>

    <script src="{{ asset('js/datatable.min.js') }}"></script>
    <script>
        $(document).ready((function(){
            var columns = [
                {
                    targets: 0,
                    orderable: true,
                    searchable: true,
                    responsivePriority: 1,
                    data: 'name',
                },
                {
                    targets: 1,
                    orderable: true,
                    searchable: true,
                    data: 'address',
                },
                {
                    targets: 2,
                    orderable: true,
                    searchable: true,
                    data: 'country.name',
                },
                {
                    targets: -1,
                    orderable: false,
                    searchable: false,
                    responsivePriority: 2,
                    data: 'action',
                }
            ];
            initdt(
                "/admin/customers",
                "/i18n/dataTable/{{auth::user()->lang}}.json",
                columns,
                "{{ __('Are you sure?')}}",
                "{{ __('You won’t be able to revert this!')}}",
                "{{ __('Yes, delete it!')}}",
                "{{ __('Cancelled')}}",
                '{{ csrf_token() }}',
                "{{ __('Error')}}!",
                "{{ __('Operation successfully completed') }}!",
                "{{ __('Data used')}}",
                "{{ __('Server Error')}}",
                "{{ __('rows')}}",
                "{{ __('Show all')}}"
            );
        }));

    </script>
@endsection
