<div class="media">
    <div class="media-left pr-1">
        <span class="avatar avatar-sm rounded-circle">
            <img src="{{ asset('storage/offers/'.$data->logo) }}" alt="avatar"><i></i>
        </span>
    </div>
    <div class="media-body media-middle">
        <a class="media-heading name">{{ $data->company }}</a>
    </div>
</div>


