<div class="btn-group btn-group-sm" role="group">
    @can('edit_offers')
        <a class="btn btn-outline-info" href="{{route('admin.offers.edit',$data->id)}}"><i class="la la-edit"></i></a>
    @endcan
    @can('delete_offers')
        <button class="btn btn-outline-danger deleteData" type="button" data-id="{{$data->id}}"><i class="la la-trash"></i></button>
    @endcan
</div>
