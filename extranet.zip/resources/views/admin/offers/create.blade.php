@extends('admin.layouts.app')

@section('title')
    {{ __('Offers') }}
@endsection

@section('active_offers', 'active')
@section('data_col', '2-columns')
@section('body_class', '2-columns')

@section('content')
<div class="content-overlay"></div>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">{{ __('Offers')}}</h3>
            <div class="row breadcrumbs-top d-inline-block">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active">{{ __('Add')}}</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-header-right col-md-6 col-12"></div>
    </div>
    <div class="content-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-icons"></h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <form class="form form-horizontal" action="{{ route('admin.offers.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="form-body">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control">{{ __('Select A New Photo') }}</label>
                                        <div class="col-md-9 mx-auto">
                                            <label id="projectinput8" class="file center-block">
                                                <input type="file" id="file" name="logo" >
                                                <span class="file-custom"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="company">{{ __('Company') }} <span class="text-danger">*</span> </label>
                                        <div class="col-md-9 mx-auto">
                                            <div class="position-relative has-icon-left">
                                                <input type="text" id="company" class="form-control" placeholder="{{ __('Company') }}" name="company" value="{{ old('company') }}">
                                                <div class="form-control-position">
                                                    <i class="la la-building"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="title">{{ __('Title') }} <span class="text-danger">*</span> </label>
                                        <div class="col-md-9 mx-auto">
                                            <div class="position-relative has-icon-left">
                                                <input type="text" id="title" class="form-control" placeholder="{{ __('Title') }}" name="title" value="{{ old('title') }}">
                                                <div class="form-control-position">
                                                    <i class="la la-building"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 label-control" for="price">{{ __('Price') }}</label>
                                        <div class="col-md-8 mx-auto">
                                            <div class="position-relative has-icon-left">
                                                <input type="number" step="0.01" id="price" class="form-control" placeholder="{{ __('Price') }}" name="price" value="{{ old('price') }}">
                                                <div class="form-control-position">
                                                    <i class="la la-dollar"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                    	<label class="col-md-3 label-control" for="experience">{{ __('Experience') }}</label>
                                    	<div class="col-md-9 mx-auto">
                                    		<div class="position-relative has-icon-left">
                                    			<textarea id="experience" rows="5" class="form-control" placeholder="{{ __('Experience') }}" name="experience" >{!! old('experience') !!}</textarea>
                                    			<div class="form-control-position">
                                    				<i class="la la-pencil"></i>
                                    			</div>
                                    		</div>
                                    	</div>
                                    </div>
                                    <div class="form-group row">
                                    	<label class="col-md-3 label-control" for="description">{{ __('Description') }}</label>
                                    	<div class="col-md-9 mx-auto">
                                    		<div class="position-relative has-icon-left">
                                    			<textarea id="description" rows="5" class="form-control" placeholder="{{ __('Description') }}" name="description" >{{old('description')}}</textarea>
                                    			<div class="form-control-position">
                                    				<i class="la la-pencil"></i>
                                    			</div>
                                    		</div>
                                    	</div>
                                    </div>
                                </div>
                                <div class="form-actions text-center">
                                    <button type="reset" class="btn btn-warning mr-1">
                                        <i class="ft-x"></i> {{ __('Cancel')}}
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="la la-check-square-o"></i> {{ __('Save')}}
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

