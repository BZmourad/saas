@extends('admin.layouts.app')

@section('title')
    {{ __('Roles') }}
@endsection

@section('style')

<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/forms/icheck/icheck.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/forms/icheck/custom.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/plugins/forms/checkboxes-radios.min.css') }}">


@endsection

@section('active_roles', 'active')
@section('data_col', '2-columns')
@section('body_class', '2-columns')

@section('content')
<div class="content-overlay"></div>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">{{ __('Administrator')}}</h3>
            <div class="row breadcrumbs-top d-inline-block">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">{{ __('Manage Account')}}</li>
                        <li class="breadcrumb-item"><a href="{{route('admin.roles.index')}}">{{ __('Roles')}}</a></li>
                        <li class="breadcrumb-item active">{{ __('Add')}}</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-header-right col-md-6 col-12"></div>
    </div>
    <div class="content-body">
        <section id="constructor">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-content collapse show">
                            <div class="card-body card-dashboard">
                                <form action="{{ route('admin.roles.store') }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <fieldset class="form-group position-relative has-icon-left">
                                        <input type="text" class="form-control round mb-1" name="name" id="name" placeholder="{{ __('Name')}}" value="{{old('name')}}">
                                        <div class="form-control-position">
                                            <i class="la la-pencil warning"></i>
                                        </div>
                                    </fieldset>
                                    <div class="">
                                        <fieldset>
                                            <input type="checkbox" id="select-all">
                                            <label for="select-all">{{ __('Give all permissions')}}</label>
                                        </fieldset>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="table-responsive">
                                                <table class="table table-bordered mt-1">
                                                    <thead class="text-white bg-cyan">
                                                        <tr>
                                                            <th>{{ __('Permissions')}}</th>
                                                            <th> <i class="la la-eye"></i> {{ __('Read')}}</th>
                                                            <th> <i class="la la-plus"></i> {{ __("Create")}}</th>
                                                            <th> <i class="la la-eye"></i> {{ __('Edit')}}</th>
                                                            <th> <i class="la la-trash"></i> {{ __('Delete')}}</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td> <i class="la la-home"></i> {{ __('Dashboard')}}</td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="access_dashboard"></label>
                                                                </fieldset>
                                                            </td>
                                                            <td class="bg-grey-blue bg-lighten-4"></td>
                                                            <td class="bg-grey-blue bg-lighten-4"></td>
                                                            <td class="bg-grey-blue bg-lighten-4"></td>
                                                        </tr>
                                                        <tr>
                                                        	<td> <i class="la la-globe"></i> {{ __('Country list')}}</td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="access_countries"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="add_countries"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="edit_countries"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="delete_countries"></label></fieldset></td>
                                                        </tr>
                                                        <tr>
                                                        	<td> <i class="la la-user-plus"></i> {{ __('Members')}}</td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="access_members"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="add_members"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="edit_members"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="delete_members"></label></fieldset></td>
                                                        </tr>
                                                        <tr>
                                                        	<td> <i class="la la-user-plus"></i> {{ __('Customers')}}</td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="access_customers"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="add_customers"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="edit_customers"></label></fieldset></td>
                                                        	<td><fieldset class="checkboxsas"><label><input type="checkbox" name="permissions[]" value="delete_customers"></label></fieldset></td>
                                                        </tr>
                                                        <tr class="bg-blue bg-lighten-3"><td colspan="5" class="text-center"> {{ __('Administrator')}}</td></tr>
                                                        <tr class="bg-blue bg-lighten-4"><td colspan="5" class="text-center"><i class="la la-users"></i> {{ __('Manage Account')}}</td></tr>
                                                        <tr>
                                                            <td> <i class="icon-users"></i> {{ __('Users')}}</td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="access_users"></label>
                                                                </fieldset>
                                                            </td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="add_users"></label>
                                                                </fieldset>
                                                            </td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="edit_users"></label>
                                                                </fieldset>
                                                            </td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="delete_users"></label>
                                                                </fieldset>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td> <i class="icon-key"></i> {{ __('Roles')}}</td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="access_roles"></label>
                                                                </fieldset>
                                                            </td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="add_roles"></label>
                                                                </fieldset>
                                                            </td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="edit_roles"></label>
                                                                </fieldset>
                                                            </td>
                                                            <td>
                                                                <fieldset class="checkboxsas">
                                                                    <label><input type="checkbox" name="permissions[]" value="delete_roles"></label>
                                                                </fieldset>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="col-12 d-flex flex-sm-row flex-column justify-content-end mt-1">
                                            <button type="submit" class="btn btn-primary glow mb-1 mb-sm-0 mr-0 mr-sm-1">{{ __('Save')}}</button>
                                            <button type="reset" class="btn btn-light">{{ __('Cancel')}}</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
@endsection

@section('script')
<script src="{{ asset('app-assets/vendors/js/forms/icheck/icheck.min.js') }}"></script>
<script src="{{ asset('app-assets/js/scripts/forms/checkbox-radio.min.js') }}"></script>

<script>
    $(document).ready(function() {
        $('#select-all').click(function() {
            var checked = this.checked;
            console.log('checked', checked);
            $('input[type="checkbox"]').each(function() {
                this.checked = checked;
            });
        });
    });
</script>
@endsection
