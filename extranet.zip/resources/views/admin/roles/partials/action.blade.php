<div class="btn-group btn-group-sm" role="group">
    @can('edit_users')
        <a class="btn btn-outline-info" href="{{route('admin.roles.edit',$data->id)}}"><i class="la la-edit"></i></a>
    @endcan
    @can('delete_users')
        <button class="btn btn-outline-danger deleteData" type="button" data-id="{{$data->id}}"><i class="la la-trash"></i></button>
    @endcan
</div>
