<div class="btn-group btn-group-sm" role="group">
    @can('edit_members')
        <a class="btn btn-outline-info" href="{{route('admin.members.edit',$data->id)}}"><i class="la la-edit"></i></a>
    @endcan
    @can('delete_members')
        <button class="btn btn-outline-danger deleteData" type="button" data-id="{{$data->id}}"><i class="la la-trash"></i></button>
    @endcan
    @php
        $id = $data->id;
        $user = \App\Models\User::where('type', 1)->where('member_id',$data->id)->whereHas('roles', function ($q) use ($id) {
            $q->where('type', 1)->where('name', 'Admin')->where('member_id', $id);
        })->first();
    @endphp
    @if ($user->is_accepted == 0)
        <button class="btn btn-outline-warning acceptData" type="button" data-id="{{$data->id}}" ><i class="la la-check-square-o"></i></button>
    @endif
</div>
