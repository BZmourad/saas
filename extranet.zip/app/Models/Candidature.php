<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Haruncpi\LaravelUserActivity\Traits\Loggable;

class Candidature extends Model
{
    use HasFactory;
    use Loggable;

    protected $fillable = [
        'candidate_id',
        'offer_id',
        'date'
    ];

    public function candidate() {
        return $this->belongsTo(Candidate::class, 'candidate_id', 'id');
    }

    public function offer() {
        return $this->belongsTo(Offer::class, 'offer_id', 'id');
    }
}
