<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Haruncpi\LaravelUserActivity\Traits\Loggable;

class Member extends Model
{
    use HasFactory;
    use Loggable;

    protected $fillable = [
        'name',
        'description',
        'address',
        'country_id',
        'created_by'
    ];

    protected $casts = [

    ];

    public function country() {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }

    public function users() {
        return $this->hasMany(User::class, 'member_id', 'id');
    }

    public function created_user() {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
}
