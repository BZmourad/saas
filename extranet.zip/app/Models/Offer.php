<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Haruncpi\LaravelUserActivity\Traits\Loggable;

class Offer extends Model
{
    use HasFactory;
    use Loggable;

    protected $fillable = [
        'company',
        'logo',
        'title',
        'description',
        'price',
        'experience',
        'created_by'
    ];

    public function created_user() {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function candidatures() {
        return $this->hasMany(Candidature::class, 'offer_id', 'id');
    }
}
