<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Haruncpi\LaravelUserActivity\Traits\Loggable;

class Country extends Model
{
    use HasFactory;
    use Loggable;

    protected $fillable = [
        'name',
        'abbreviation',
    ];

    public function members() {
        return $this->hasMany(Member::class, 'country_id', 'id');
    }

    public function customers() {
        return $this->hasMany(Customer::class, 'country_id', 'id');
    }

    public function candidates() {
        return $this->hasMany(Candidate::class, 'country_id', 'id');
    }

}
