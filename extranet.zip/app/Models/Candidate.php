<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Haruncpi\LaravelUserActivity\Traits\Loggable;

class Candidate extends Model
{
    use HasFactory;
    use Loggable;

    protected $fillable = [
        'firstname',
        'lastname',
        'birthday',
        'description',
        'job',
        'address',
        'city',
        'postal_code',
        'country_id',
        'email',
        'phone',
        'facebook',
        'whatsapp',
        'skype',
        'twitter',
    ];

    public function country() {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }

    public function user() {
        return $this->hasOne(User::class, 'candidate_id', 'id');
    }

    public function candidatures() {
        return $this->hasMany(Candidature::class, 'candidate_id', 'id');
    }

}
