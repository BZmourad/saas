<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\Member;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Validation\Rules\Password as PasswordRule;
use Hash;
use Mail;
use App\Mail\UserParameter;

class MemberController extends Controller
{
    function __construct(){
        $this->middleware('permission:access_members', ['only' => ['index']]);
        $this->middleware('permission:add_members', ['only' => ['create','store']]);
        $this->middleware('permission:edit_members', ['only' => ['edit','update1']]);
        $this->middleware('permission:delete_members', ['only' => ['destroy']]);
    }

    public function index() {
        if(request()->ajax()) {
            return DataTables::of(Member::query()->with('country')->latest())
                ->addColumn('action', function ($data) {
                    return view('admin.members.partials.action', [ 'data' => $data ]);
                })->make(true);
        }
        return view('admin.members.index');
    }

    public function create() {
        return view('admin.members.create');
    }

    public function store(Request $request) {
        $validator = Validator::make($request->all(), [
            'company_name' => ['required','unique:members,name','string','min:3'],
            'description' => ['nullable','string'],
            'address' => ['nullable','string','min:3'],
            'country_id' => ['nullable'],
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $member = Member::create([
            'name' => $request->company_name,
            'description' => $request->description,
            'address' => $request->address,
            'country_id' => $request->country_id,
            'created_by' => auth()->user()->id
        ]);
        return redirect()->route('admin.members.index')->with('message','success');
    }

    public function accept($id) {
        Member::findOrFail($id)->update(['is_accepted' => true]);
        $user = User::where('type', 1)->where('member_id',$id)->whereHas('roles', function ($q) use ($id) {
            $q->where('type', 1)->where('name', 'Admin')->where('member_id', $id);
        })->first();
        $user->update(['is_accepted' => true]);
        return response()->json([ 'success'=>true ]);
    }

    public function edit($id) {
        $member = Member::findOrFail($id);
        return view('admin.members.edit', compact('member'));
    }

    public function update1(Request $request) {
        $validator = Validator::make($request->all(), [
            'company_name' => ['required','unique:members,name,'.$request->id,'string','min:3'],
            'description' => ['nullable','string'],
            'address' => ['nullable','string','min:3'],
            'country_id' => ['nullable'],
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $member = Member::findOrFail($request->id);
        $member->update([
            'name' => $request->company_name,
            'description' => $request->description,
            'address' => $request->address,
            'country_id' => $request->country_id,
        ]);
        return redirect()->route('admin.members.index')->with('message','success');
    }

    public function destroy($id) {
        Member::findOrFail($id)->delete();
        return response()->json([ 'success'=>true ]);
    }
}
