<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use Illuminate\Validation\Rule;
use App\Http\Controllers\Controller;

class RoleController extends Controller
{
    function __construct(){
        $this->middleware('permission:access_roles', ['only' => ['index']]);
        $this->middleware('permission:add_roles', ['only' => ['create','store']]);
        $this->middleware('permission:edit_roles', ['only' => ['edit','update1']]);
        $this->middleware('permission:delete_roles', ['only' => ['destroy']]);
    }

    public function index() {
        if(request()->ajax()) {
            return DataTables::of(Role::query()->where('type',0)->latest())
                ->addColumn('created_at', function ($data) {
                    return $data->created_at->diffForHumans();
                })
                ->addColumn('nb_users', function ($data) {
                    $id = $data->id;
                    $users = User::whereHas('roles', function ($q) use ($id) {
                        $q->where('id', $id);
                    })->get()->count();
                    return $users;
                })
                ->addColumn('action', function ($data) {
                    return view('admin.roles.partials.action', [ 'data' => $data ]);
                })
                ->make(true);
        }
        return view('admin.roles.index');
    }

    public function create() {
        return view('admin.roles.create');
    }

    public function store(Request $request) {
        $validator = Validator::make($request->all(), [
            'name' => [Rule::unique('roles')->where(fn ($query) => $query->where('type', 0)),'required', 'string', 'max:255'],
            'permissions' => 'required|array'
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $role = Role::create([
            'name' => $request->name,
            'membre' => 0
        ]);
        $role->givePermissionTo($request->permissions);
        return redirect()->route('admin.roles.index')->with('message','success');
    }

    public function edit($id) {
        $role = Role::findOrFail($id);
        return view('admin.roles.edit', compact('role'));
    }

    public function update1(Request $request) {
        $validator = Validator::make($request->all(), [
            'name' => [Rule::unique('roles')->where(fn ($query) => $query->where('type', 0)->where('id', '<>', $request->id)),'required', 'string', 'max:255'],
            'permissions' => 'required|array'
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $role = Role::findOrFail($request->id);
        $role->update([
            'name' => $request->name
        ]);
        $role->syncPermissions($request->permissions);
        return redirect()->route('admin.roles.index')->with('message','success');
    }

    public function destroy($id) {
        $role = Role::findOrFail($id);
        $name = $role->id;
        $users = User::whereHas('roles', function ($q) use ($name) {
            $q->where('id', $name);
        })->get()->count();
        if ($users != 0) {
            return response()->json(['errors'=> true ]);
        }
        $role->delete();
        return response()->json([ 'success'=>true ]);
    }
}
