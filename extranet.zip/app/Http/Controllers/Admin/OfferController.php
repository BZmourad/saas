<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use App\Http\Controllers\Controller;
use App\Models\Offer;
use Illuminate\Support\Facades\File;

class OfferController extends Controller
{
    function __construct(){
        $this->middleware('permission:access_offers', ['only' => ['index']]);
        $this->middleware('permission:add_offers', ['only' => ['create','store']]);
        $this->middleware('permission:edit_offers', ['only' => ['edit','update1']]);
        $this->middleware('permission:delete_offers', ['only' => ['destroy']]);
    }

    public function index() {
        if(request()->ajax()) {
            return DataTables::of(Offer::query()->latest())
                ->addColumn('company', function($data) {
                    return view('admin.offers.partials.name', [ 'data' => $data ]);
                })
                ->addColumn('action', function ($data) {
                    return view('admin.offers.partials.action', [ 'data' => $data ]);
                })->make(true);
        }
        return view('admin.offers.index');
    }

    public function create() {
        return view('admin.offers.create');
    }

    public function store(Request $request) {
        $validator = Validator::make($request->all(), [
            'company' => ['required','string','min:3'],
            'description' => ['nullable','string'],
            'logo' => 'nullable|image|mimes:jpg,png,jpeg,gif,svg',
            'title' => ['required','string','min:3'],
            'price' => ['required','numeric','min:0'],
            'experience' => ['required','string','min:3'],
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $offer = Offer::create([
            'company' => $request->company,
            'description' => $request->description,
            'title' => $request->title,
            'price' => $request->price,
            'experience' => $request->experience,
            'created_by' => auth()->user()->id
        ]);
        if ($request->hasfile('logo')) {
            $imageName = time().'.'.$request->logo->getClientOriginalExtension();
            $request->logo->move('storage/offers', $imageName);
            $offer->logo = $imageName;
            $offer->update();
        }
        return redirect()->route('admin.offers.index')->with('message','success');
    }

    public function edit($id) {
        $offer = Offer::findOrFail($id);
        return view('admin.offers.edit', compact('offer'));
    }

    public function update1(Request $request) {
        $validator = Validator::make($request->all(), [
            'company' => ['required','string','min:3'],
            'description' => ['nullable','string'],
            'logo' => 'nullable|image|mimes:jpg,png,jpeg,gif,svg',
            'title' => ['required','string','min:3'],
            'price' => ['required','numeric','min:0'],
            'experience' => ['required','string','min:3'],
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $offer = Offer::findOrFail($request->id);
        $offer->update([
            'company' => $request->company,
            'description' => $request->description,
            'title' => $request->title,
            'price' => $request->price,
            'experience' => $request->experience,
        ]);
        if ($request->hasfile('logo')) {
            if ($user->avatar != 'new-offer.jpg') {
                File::delete('storage/offers/'.$offer->logo);
            }
            $imageName = time().'.'.$request->logo->getClientOriginalExtension();
            $request->logo->move('storage/offers', $imageName);
            $offer->logo = $imageName;
            $offer->update();
        }
        return redirect()->route('admin.offers.index')->with('message','success');
    }

    public function destroy($id) {
        Offer::findOrFail($id)->delete();
        return response()->json([ 'success'=>true ]);
    }
}
