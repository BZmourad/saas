<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class HomeAdminController extends Controller
{
    function __construct(){
        $this->middleware('permission:access_dashboard');
    }

    public function index(){
        return view('admin.home');
    }
}
