<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\Country;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Controller;

class CountryController extends Controller
{
    function __construct(){
        $this->middleware('permission:access_countries', ['only' => ['index']]);
        $this->middleware('permission:add_countries', ['only' => ['create','store']]);
        $this->middleware('permission:edit_countries', ['only' => ['edit','update1']]);
        $this->middleware('permission:delete_countries', ['only' => ['destroy']]);
    }

    public function index() {
        if(request()->ajax()) {
            return DataTables::of(Country::query()->latest())
                ->addColumn('action', function ($data) {
                    return view('admin.countries.partials.action', [ 'data' => $data ]);
                })->make(true);
        }
        return view('admin.countries.index');
    }

    public function create() {
        return view('admin.countries.create');
    }

    public function store(Request $request) {
        $validator = Validator::make($request->all(), [
            'name' => ['unique:countries,name','required','string','min:3'],
            'abbreviation' => ['unique:countries,abbreviation','required','string','min:2']
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $country = Country::create([
            'name' => $request->name,
            'abbreviation' => $request->abbreviation
        ]);
        return redirect()->route('admin.countries.index')->with('message','success');
    }

    public function edit($id) {
        $country = Country::findOrFail($id);
        return view('admin.countries.edit', compact('country'));
    }

    public function update1(Request $request) {
        $validator = Validator::make($request->all(), [
            'name' => ['unique:countries,name,'.$request->id,'required','string','min:3'],
            'abbreviation' => ['unique:countries,abbreviation,'.$request->id,'required','string','min:2']
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $country = Country::findOrFail($request->id);
        $country->update([
            'name' => $request->name,
            'abbreviation' => $request->abbreviation
        ]);
        return redirect()->route('admin.countries.index')->with('message','success');
    }

    public function destroy($id) {
        Country::findOrFail($id)->delete();
        return response()->json([ 'success'=>true ]);
    }
}
