<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\Customer;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Validation\Rules\Password as PasswordRule;
use Hash;
use Mail;
use App\Mail\UserParameter;

class CustomerController extends Controller
{
    function __construct(){
        $this->middleware('permission:access_customers', ['only' => ['index']]);
        $this->middleware('permission:add_customers', ['only' => ['create','store']]);
        $this->middleware('permission:edit_customers', ['only' => ['edit','update1']]);
        $this->middleware('permission:delete_customers', ['only' => ['destroy']]);
    }

    public function index() {
        if(request()->ajax()) {
            return DataTables::of(Customer::query()->with('country')->latest())
                ->addColumn('action', function ($data) {
                    return view('admin.customers.partials.action', [ 'data' => $data ]);
                })->make(true);
        }
        return view('admin.customers.index');
    }

    public function create() {
        return view('admin.customers.create');
    }

    public function store(Request $request) {
        $validator = Validator::make($request->all(), [
            'company_name' => ['required','unique:customers,name','string','min:3'],
            'description' => ['nullable','string'],
            'address' => ['nullable','string','min:3'],
            'country_id' => ['nullable'],
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $customer = Customer::create([
            'name' => $request->company_name,
            'description' => $request->description,
            'address' => $request->address,
            'country_id' => $request->country_id,
            'created_by' => auth()->user()->id
        ]);
        return redirect()->route('admin.customers.index')->with('message','success');
    }

    public function edit($id) {
        $customer = Customer::findOrFail($id);
        return view('admin.customers.edit', compact('customer'));
    }

    public function update1(Request $request) {
        $validator = Validator::make($request->all(), [
            'company_name' => ['required','unique:customers,name,'.$request->id,'string','min:3'],
            'description' => ['nullable','string'],
            'address' => ['nullable','string','min:3'],
            'country_id' => ['nullable'],
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $customer = Customer::findOrFail($request->id);
        $customer->update([
            'name' => $request->company_name,
            'description' => $request->description,
            'address' => $request->address,
            'country_id' => $request->country_id,
        ]);
        return redirect()->route('admin.customers.index')->with('message','success');
    }

    public function destroy($id) {
        Customer::findOrFail($id)->delete();
        return response()->json([ 'success'=>true ]);
    }
}
