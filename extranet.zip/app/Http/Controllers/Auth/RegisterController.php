<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Member;
use App\Models\Customer;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Validation\Rules\Password as PasswordRule;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'company_name' => ['required','string','min:3'],
            'description' => ['nullable','string'],
            'address' => ['nullable','string','min:3'],
            'country_id' => ['nullable'],
            'type' => ['required'],
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', PasswordRule::min(8)->mixedCase()->letters()->numbers()->symbols(), 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        if ($data['type'] == 1) {
            $member = Member::create([
                'name' => $data['company_name'],
                'description' => $data['description'],
                'address' => $data['address'],
                'country_id' => $data['country_id'],
            ]);
            $user = User::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => Hash::make($data['password']),
                'type' => 1,
                'member_id' => $member->id
            ]);
            $roleSuperAdmin = Role::create(['name' => 'Admin','type'=> 1,'member_id'=>$member->id]);
            $permissions = Permission::where('type', 1)->pluck('id','id')->all();
            $roleSuperAdmin->syncPermissions($permissions);
            $user->assignRole([$roleSuperAdmin->id]);
            return $user;
        } else {
            $customer = Customer::create([
                'name' => $data['company_name'],
                'description' => $data['description'],
                'address' => $data['address'],
                'country_id' => $data['country_id'],
            ]);
            return User::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => Hash::make($data['password']),
                'type' => 2,
                'customer_id' => $customer->id
            ]);
        }


    }
}
