<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Offer;
use App\Models\Candidate;
use App\Models\Candidature;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password as PasswordRule;

class HomeController extends Controller
{

    public function welcome(){
        return view('welcome');
    }

    public function index(){
        if (Auth::user()->type == 'admin') {
            return redirect("/admin/home");
        } else if (Auth::user()->type == 'member') {
            return redirect("/member/home");
        } else if (Auth::user()->type == 'customer') {
            return redirect("/customer/home");
        } else if (Auth::user()->type == 'candidat') {
            return redirect("/candidat/home");
        }
    }

    public function setLang($lang){
        Auth::user()->update(['lang' => $lang]);
        return redirect()->back()->with('message','success');
    }

    public function getOffers($id){
        $offer = Offer::findOrFail($id);
        return view('offer', compact('offer'));
    }

    public function postulate($id){
        $offer = Offer::findOrFail($id);
        return view('postulate', compact('offer'));
    }

    public function candidature(Request $request){
        $validator = Validator::make($request->all(), [
            'image' => 'nullable|image|mimes:jpg,png,jpeg,gif,svg',
            'firstname' => ['required'],
            'lastname' => ['required'],
            'birthday' => ['required'],
            'job' => ['required'],
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', PasswordRule::min(8)->mixedCase()->letters()->numbers()->symbols(), 'confirmed'],
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $candidate = Candidate::create([
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'birthday' => $request->birthday,
            'description' => $request->description,
            'job' => $request->job,
            'address' => $request->address,
            'city' => $request->city,
            'postal_code' => $request->postal_code,
            'country_id' => $request->country_id,
            'email' => $request->email,
            'phone' => $request->phone,
            'facebook' => $request->facebook,
            'whatsapp' => $request->whatsapp,
            'skype' => $request->skype,
            'twitter' => $request->twitter,
        ]);
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'type' => 3,
            'candidate_id' =>$candidate->id
        ]);
        if ($request->hasfile('image')) {
            $imageName = time().'.'.$request->image->getClientOriginalExtension();
            $request->image->move('storage/users', $imageName);
            $user->avatar = $imageName;
            $user->update();
        }
        Candidature::create([
            'candidate_id' => $candidate->id,
            'offer_id' => $request->offer_id,
            'date' => now()
        ]);
        return redirect()->route('welcome')->with('message','success');
    }
}
