<?php

namespace App\Http\Controllers\Customer;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class HomeCustomerController extends Controller
{
    public function index(){
        return view('customer.home');
    }
}
