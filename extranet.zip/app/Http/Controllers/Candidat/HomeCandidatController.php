<?php

namespace App\Http\Controllers\Candidat;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class HomeCandidatController extends Controller
{
    public function index(){
        return view('candidat.home');
    }
}
