<?php

namespace App\Http\Controllers\Candidat;

use Illuminate\Http\Request;
use App\Models\Candidate;
use App\Models\Candidature;
use Yajra\DataTables\DataTables;
use App\Http\Controllers\Controller;

class CandidatureCandidatController extends Controller
{
    public function index() {
        if(request()->ajax()) {
            return DataTables::of(Candidature::query()->with('offer')->with('candidate')->where('candidate_id',getCandidate()->id)->orderBy('candidatures.created_at', 'desc'))
                ->addColumn('action', function ($data) {
                    return view('candidat.candidature.partials.action', [ 'data' => $data ]);
                })->make(true);
        }
        return view('candidat.candidature.index');
    }
}
