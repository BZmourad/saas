<?php

namespace App\Http\Controllers\Member;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use Illuminate\Validation\Rules\Password as PasswordRule;
use Hash;
use Illuminate\Support\Facades\File;
use Mail;
use App\Mail\UserParameter;
use App\Http\Controllers\Controller;

class UserMemberController extends Controller
{
    function __construct(){
        $this->middleware('permission:access_users_member', ['only' => ['index']]);
        $this->middleware('permission:add_users_member', ['only' => ['create','store']]);
        $this->middleware('permission:edit_users_member', ['only' => ['edit','update1']]);
        $this->middleware('permission:delete_users_member', ['only' => ['destroy']]);
    }

    public function index() {
        if(request()->ajax()) {
            return DataTables::of(User::query()->where('type', 1)->where('member_id',getMember()->id)->latest())
                ->addColumn('name', function($data) {
                    return view('member.users.partials.name', [ 'data' => $data ]);
                })
                ->addColumn('role', function($data) {
                    return view('member.users.partials.role', [ 'data' => $data ]);
                })
                ->addColumn('status', function($data) {
                    return view('member.users.partials.status', [ 'data' => $data ]);
                })
                ->addColumn('created_at', function ($data) {
                    return $data->created_at->diffForHumans();
                })
                ->addColumn('last_seen', function ($data) {
                    if ($data->last_seen != null) {
                        return $data->last_seen->diffForHumans();
                    } else {
                        return '';
                    }
                })
                ->addColumn('action', function ($data) {
                    return view('member.users.partials.action', [ 'data' => $data ]);
                })->make(true);
        }
        return view('member.users.index');
    }

    public function create() {
        return view('member.users.create');
    }

    public function store(Request $request) {
        $validator = Validator::make($request->all(), [
            'role'  => 'required',
            'email' => ['required', 'unique:users,email','email'],
            'name' => 'required',
            'password' => ['required', PasswordRule::min(8)->mixedCase()->letters()->numbers()->symbols()],
            'password_confirmation' => 'required|same:password',
            'avatar' => 'nullable|image|mimes:jpg,png,jpeg,gif,svg'
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $user = User::create([
            'email' => $request->email,
            'name' => $request->name,
            'password' => Hash::make($request->password),
            'member_id' => getMember()->id,
            'type' => 1
        ]);
        if ($request->hasfile('avatar')) {
            $imageName = time().'.'.$request->avatar->getClientOriginalExtension();
            $request->avatar->move('storage/users', $imageName);
            $user->avatar = $imageName;
            $user->update();
        }
        $user->assignRole($request->input('role'));
        if (isset($request->user_send_email)) {
            $this->sendUserEmail($user, $request->password);
        }
        return redirect()->route('member.users.index')->with('message','success');
    }

    public function edit($id) {
        $user = User::findOrFail($id);
        return view('member.users.edit', compact('user'));
    }

    public function update1(Request $request) {
        $validator = Validator::make($request->all(), [
            'role'  => 'required',
            'email' => ['required', 'email', 'unique:users,email,'.$request->id],
            'name' => 'required',
            'password'=>['nullable',PasswordRule::min(8)->mixedCase()->letters()->numbers()->symbols()],
            'password_confirmation' => 'same:password',
            'avatar' => 'nullable|image|mimes:jpg,png,jpeg,gif,svg'
        ]);
        if ($validator->fails()) {return redirect()->back()->with('errors',$validator->errors()->first());}
        $user = User::findOrFail($request->id);
        $password = $user->password;
        if (!empty($request->password)) {
            $password = Hash::make($request->password);
        }
        $user->update([
            'email' => $request->email,
            'name' => $request->name,
            'password' => $password,
            'member_id' => getMember()->id,
            'type' => 1
        ]);
        if ($request->hasfile('avatar')) {
            if ($user->avatar != 'avatar.png') {
                File::delete('storage/users/'.$user->avatar);
            }
            $imageName = time().'.'.$request->avatar->getClientOriginalExtension();
            $request->avatar->move('storage/users', $imageName);
            $user->avatar = $imageName;
            $user->update();
        }
        $user->syncRoles($request->input('role'));

        if (isset($request->user_send_email) && !empty($request->password)) {
            $this->sendUserEmail($user, $request->password);
        }
        return redirect()->route('member.users.index')->with('message','success');
    }

    public function destroy($id) {
        User::findOrFail($id)->delete();
        return response()->json([ 'success'=>true ]);
    }

    protected function sendUserEmail($user, $plainPassword){
        Mail::to($user->email)->queue(new UserParameter($user, $plainPassword));
    }
}
