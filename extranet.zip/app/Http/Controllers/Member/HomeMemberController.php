<?php

namespace App\Http\Controllers\Member;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class HomeMemberController extends Controller
{
    function __construct(){
        $this->middleware('permission:access_dashboard_member');
    }

    public function index(){
        return view('member.home');
    }
}
