<?php
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use App\Models\Member;
use App\Models\Customer;
use App\Models\Candidate;

if (! function_exists('writeLog')) {
    function writeLog($str){
        Log::info('writeLog '.$str);
    }
}

if (! function_exists('getMember')) {
    function getMember(){
        $member = Member::findOrFail(Auth::user()->member_id);
        return $member;
    }
}

if (! function_exists('getCustomer')) {
    function getCustomer(){
        $customer = Customer::findOrFail(Auth::user()->customer_id);
        return $customer;
    }
}

if (! function_exists('getCandidate')) {
    function getCandidate(){
        $customer = Candidate::findOrFail(Auth::user()->candidate_id);
        return $customer;
    }
}
